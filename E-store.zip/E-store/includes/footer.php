<footer>
    <div class="container">
        <center>
            <p>Copyright &copy; ViralElectronics. All Rights Reserved  |  Contact Us: +91 9999 2511 57</p>	
        </center>
    </div>
</footer>